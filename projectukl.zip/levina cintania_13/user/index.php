<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Website SMK</title>
<link rel="stylesheet" href="style2.css">
</head>
<body>

<header>
    <nav>
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">Profile Sekolah</a></li>
            <li><a href="#courses">Ektrakulikuler</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>
</header>

<main>
    <section id="home">
        <div class="hero">
            <h1>SMK TELKOM SIDOARJO</h1>
            <p>SCHOOL OF DIGITAL ERA</p>
            <a href="#courses" class="btn">Explore Courses</a>
        </div>
    </section>

    <section id="about">
        <div class="about-content">
            <h2>Profile Sekolah</h2>
            <p>SMK Telkom Sidoarjo merupakan Sekolah Menengah Kejuruan bidang Teknologi dan Informatika yang dibawah naungan Yayasan Pendidikan Telkom. SMK Telkom Sidoarjo berdiri pada tahun 2018 dan sudah terakreditasi "A" dan mempunyai standart mutu ISO 21001:2018. 

SMK Telkom Sidoarjo memiliki dua jurusan yaitu Teknik Jaringan Akses Telekomunikasi (TJAT) dan Sistem Informasi Jaringan dan Aplikasi (SIJA). Disini para siswa kami dibimbing untuk bisa memahami, mengoperasikan hingga memelihara berbagai perangkat utama dan pendukung jaringan telekomunikasi dari berbagai operator telekomunikasi maupun perusahaan-perusahaan pengguna sarana telekomunikasi.

SMK Telkom Sidoarjo menggunakan kurikulum Nasional Plus. Kurikulum Nasional Plus yaitu kurikulum disesuaikan dengan kebutuhan industri saat ini, sehingga lulusan SMK Telkom Sidoarjo nantinya bisa memiliki keterampilan dan langsung bekerja di industry era digital ini.

 </p>
        </div>
    </section>

    <section id="courses">
        <h2>Ektrakulikuler</h2>
        <div class="course-card">
            <img src="course1.jpg" alt="Course 1">
            <h3>Ektrakulikuler Basket</h3>
            <p>Ekstrakurikuler basket adalah kegiatan olahraga bola besar. Kegiatan ini biasanya meliputi latihan teknik dasar basket seperti dribbling, shooting, passing, dan strategi permainan.</p>
            <a href="#" class="btn">Enroll Now</a>
        </div>
        <div class="course-card">
            <img src="course2.jpg" alt="Course 2">
            <h3>Ektrakulikuler Ambalan</h3>
            <p>Ektrakulikuler ambalan adalah kegiatan petualangan, mencoba hal baru untuk melatih kerja sama tim dan sikap tanggung jawab dan keberanian siswa.</p>
            <a href="#" class="btn">Enroll Now</a>
        </div>
        <!-- Add more course cards here -->
    </section>

    <section id="contact">
        <div class="contact-form">
            <h2>Contact Us</h2>
            <form action="#">
                <input type="text" placeholder="Your Name">
                <input type="email" placeholder="Your Email">
                <textarea placeholder="Your Message"></textarea>
                <button type="submit" class="btn">Send Message</button>
            </form>
        </div>
    </section>
</main>

<footer>
    <p>&copy; SMK TELKOM SIDOARJO.</p>
</footer>

</body>
</html>
