<body>
    <header>
        <h3>Formulir Edit User</h3>
    </header>
    <from method="POST" action="proses_edit_user.php">
        <table>
            <tr>
                   <td>Nama</td>
                   <td><input type="text" name="nama" value="<?php echo $nama;?>"></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="password" name="username" value="<php echo $username />"></td>
                </tr>
                <tr>  
                    <td>Level</td>
                    <td>
                    <select name="level" id="level" require>
                    <option disabled selected> <?php echo $level ?></option>
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                    </select>
                    </td>
                </tr>
                <tr>
                     <td><input type="hiddn" name="id" value =<?php echo $_GET['id'];?>></td>
                     <td><input type="submit" name="simpan" value="Simpan"></td>
                </tr>
            </table>     
        </form>
</body>

<?php
include("../koneksi.php");
 //kalau tidak ada id di query string
 if(!isset($_GET['id']) ){
    header('Location: index.php');
 }
 $id = $_GET['id'];

 //Feetech usr data based on id 
 $result = mysqli_query($mysqli, "SELECT * FROM user WHERE id=$id");

 while($user_data = mysqli_fetch_array($result))
 {
    $nama = $user_data['nama'];
    $username = $user_data['username'];
    $password = $user_data['password'];
    $level = $user_data['level'];
 }


<?php

include("../koneksi.php");

//cek apakah tombol simpan sudah diklik atau belum?
if(isset($_POST['simpan'])){

    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = $_POST['level'];

    //buat query update
    $result = mysqli_query($mysqli, "UPDATE user
    SET nama='$nama',username='$username',password='$password',level='$level'
    WHERE id=$id");
    header('Location: index.php');
} else {
    die("Akses dilarang...");
    }
?>


