<?php
// Memulai sesi
session_start();

// Cek apakah pengguna sudah login atau belum
if (!isset($_SESSION['username'])) {
    // Jika belum, arahkan ke halaman login
    header('Location: login.php');
    exit();
}

// Menghubungkan ke database
include 'koneksi.php';

// Ambil data dari form
$id = $_POST['id'];
$nama = $_POST['nama'];
$email = $_POST['email'];
$telepon = $_POST['telepon'];

// Query untuk mengupdate data
$query = "UPDATE tabel_pengguna SET nama='$nama', email='$email', telepon='$telepon' WHERE id='$id'";

// Eksekusi query
if (mysqli_query($koneksi, $query)) {
    // Jika berhasil, arahkan ke halaman utama
    header('Location: index.php');
    exit();
} else {
    // Jika gagal, tampilkan pesan error
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}

// Tutup koneksi database
mysqli_close($koneksi);
?>
