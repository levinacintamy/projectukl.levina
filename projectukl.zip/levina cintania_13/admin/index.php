<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CRUD Table</title>
<link rel="stylesheet" href="index.css">
</head>
<body>

<div class="container">
    <h1>CRUED</h1>
    <table>
        <thead>
            <tr>
                <th>nama</th>
                <th>username</th>
                <th>password</th>
                <th>level</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>ceces</td>
                <td>ceces@gmail.com</td>
                <td>
                    <button>admin</button>
                </td>
            </tr>
            <!-- Other rows go here -->
        </tbody>
    </table>
    <button>Add Admin</button>
</div>

</body>
</html>
